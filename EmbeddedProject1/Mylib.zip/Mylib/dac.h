#ifndef __DAC_H__
#define __DAC_H__

#include "stm32f4xx_hal.h"

void dac_init(void);
void dac_set(uint32_t data);

#endif





