#ifndef __USART2_H__
#define __USART2_H__

#include "stm32f4xx_hal.h"
#include "stdio.h"
#include <string.h>
#include <stdarg.h>

void usart2_init(void);
void usart2_send(char *b);

#endif
