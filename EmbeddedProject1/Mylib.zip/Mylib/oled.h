#ifndef __OLED_H__
#define __OLED_H__

void OLED_Configuration(void);  
void OLED_Print(unsigned char x, unsigned char y, char ch[]);
void OLED_Printf(unsigned char x,unsigned char y,const char *fmt,...);
void LCD_P8x16Str(unsigned char x,unsigned char y,char ch[]);

void OLED_Clear(void);
void plot(unsigned char data[]);
void plot1(unsigned char data[]);
void line(unsigned char x);
void plot_128(unsigned char data[]);

#endif 
