#ifndef __TIM3_H_
#define __TIM3_H_
#define LED_1HZ  100
#define LED_5HZ  20
#define LED_10HZ 10


void tim3_init(void);


#endif




